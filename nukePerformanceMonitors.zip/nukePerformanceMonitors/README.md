Copy text into menu.py file.
Copy icon into icons folder in the .nuke folder.

Creates a button in the toolbar that can toggle nuke's performance monitors used to debug a script and discover heavy nodes.

#To do:
	Create a select button based of heavy and medium to heavy nodes and incoorporate with the disable gizmo